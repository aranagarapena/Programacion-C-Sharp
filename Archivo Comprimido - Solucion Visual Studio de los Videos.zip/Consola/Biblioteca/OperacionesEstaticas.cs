﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public static class OperacionesEstaticas
    {
        public static double CalcularCuadrado(double numero) {
            return numero * numero;
        }


        public static double CalcularSuma(double numero, double numero2)
        {
            return numero + numero2;
        }

    }
}
